#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Arvore_bin.h"
#include "Compress.h"
#include "Lista.h"
#include "tabela_mani.h"

void compressFile(const std::string& inputFilePath, const std::string& outputFilePath) {
    // Inicializa as estruturas necess�rias
    lista lista_ordenada;
    inicializa_lista(&lista_ordenada);

    // L� o arquivo de entrada
    std::ifstream inputFile(inputFilePath, std::ios::binary);
    if (!inputFile) {
        std::cerr << "Erro ao abrir o arquivo de entrada: " << inputFilePath << std::endl;
        return;
    }

    // L� o conte�do do arquivo
    std::string content((std::istreambuf_iterator<char>(inputFile)), std::istreambuf_iterator<char>());
    inputFile.close();

    // Cria a tabela de frequ�ncia dos caracteres
    unsigned char tabela_probabilidade[TAB_OFFSET] = {0};
    if (tabela(const_cast<char*>(content.c_str()), tabela_probabilidade) != 0) {
        std::cerr << "Erro: Estouro na tabela de probabilidade." << std::endl;
        return;
    }

    // Constroi a lista ordenada e a �rvore de Huffman
    constroi_lista(tabela_probabilidade, &lista_ordenada);
    constroi_arvore(&lista_ordenada);

    // Inicializa as vari�veis necess�rias para a compress�o
    unsigned int tamanho_dado_compactado = 0;
    unsigned char bits = 7;
    unsigned char aux_cod = 0;
    std::vector<unsigned char> mensagem_code(TAB_OFFSET + content.size() * 8, 0);

    // Executa a compress�o
    compress_dado(const_cast<char*>(content.c_str()), &tamanho_dado_compactado, &bits, &aux_cod, mensagem_code.data(), lista_ordenada.head->dado);

    // Salva a mensagem comprimida no arquivo de sa�da
    std::ofstream outputFile(outputFilePath, std::ios::binary);
    if (!outputFile) {
        std::cerr << "Erro ao abrir o arquivo de sa�da: " << outputFilePath << std::endl;
        return;
    }

    outputFile.write(reinterpret_cast<const char*>(mensagem_code.data()), tamanho_dado_compactado + TAB_OFFSET);
    outputFile.close();

    std::cout << "Arquivo comprimido com sucesso: " << outputFilePath << std::endl;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Uso: " << argv[0] << " <arquivo_entrada> <arquivo_saida>" << std::endl;
        return 1;
    }

    std::string inputFilePath = argv[1];
    std::string outputFilePath = argv[2];

    compressFile(inputFilePath, outputFilePath);

    return 0;
}
