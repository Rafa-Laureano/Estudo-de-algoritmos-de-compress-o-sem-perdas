#define tipoS 66
#include "tabela_mani.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

int tabela(char *v, unsigned char *t) {
    char *token;
    token = strtok(v, "#");
    v = token;
    int aux2 = 0;
    int size = strlen(v);

    for (int i = 0; i < size; i++) {
        int aux = v[i] - 48; // ASCII PARA BINARIO NORMAL
        if (aux <= 9 && aux >= 0) {
            t[aux] += 1;
            if (t[aux] > 254) {
                printf("\n TAMANHO MAX %d %d\n", aux, t[aux]);
                return 1;
            }
        } else {
            if (aux == -3) {
                t[10] += 1;
                if (t[10] > 254) {
                    printf("\n TAMANHO MAX %d \n", t[10]);
                    return 1;
                }
            } else if (aux == -4) {
                t[11] += 1;
                if (t[11] > 254) {
                    printf("\n TAMANHO MAX %d \n", t[11]);
                    return 1;
                }
                aux2++;
            } else {
                t[12] += 1;
                if (t[12] > 254) {
                    printf("\n TAMANHO ELSE MAX %d \n", t[12]);
                    return 1;
                }
            }
        }
    }
    return 0;
}

void print_tab(unsigned char *v) {
    for (int i = 0; i < 10; i++) {
        printf("\n %d %d \n", i, v[i]);
    }
    printf("\n %c %d \n", '-', v[10]);
    printf("\n < %d \n", v[11]);
    printf("\n > %d \n", v[12]);
    printf("\n & %d \n", v[13]);
    printf("\n . %d \n", v[14]);
}
